using UnityEngine;

public class NewEmptyCSharpScript : MonoBehaviour
{
    private Rigidbody2D myrigidbody2D;
    public float bulletSpeed = 10f; 
    public GameManager myGameManager;

    void Start()
    {
        myrigidbody2D = GetComponent<Rigidbody2D>();
        myGameManager = FindObjectOfType<GameManager>();
    }

    void Update()
    {
        myrigidbody2D.linearVelocity = new Vector2(bulletSpeed,
        myrigidbody2D.linearVelocity.y);
    }
    
}
