using System.Collections;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject[] itemPrefab;
    public float minTime = 1f;
    public float maxTime = 2f;

    void Start()
    {
        // Comienza la primera llamada a la corrutina
        StartCoroutine(SpawnCoRutine(0));
    }

    IEnumerator SpawnCoRutine(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);

        // Verifica que el arreglo no esté vacío antes de instanciar
        if (itemPrefab.Length > 0)
        {
            Instantiate(itemPrefab[Random.Range(0, itemPrefab.Length)], transform.position, Quaternion.identity);
        }

        // Llama de nuevo a la corrutina con un tiempo aleatorio
        StartCoroutine(SpawnCoRutine(Random.Range(minTime, maxTime)));
    }
}
