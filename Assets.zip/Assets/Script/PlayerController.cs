using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public float playerJumpForce = 20f;
    public float playerSpeed = 3f;
    public Sprite[] walkSprites; //es como el "mysprite" de la profe
    public Sprite jumpSprite;

    private int walkIndex = 0; //es como el index de la profe
    private Rigidbody2D myrigidbody2D;
    public GameObject Bullet;
    private SpriteRenderer mySpriteRenderer;
    public GameManager myGameManager;

    void Start()
    {
        // Inicializa los componentes necesarios
        myrigidbody2D = GetComponent<Rigidbody2D>();
        mySpriteRenderer = GetComponent<SpriteRenderer>();
        myGameManager = FindAnyObjectByType<GameManager>();
        // Inicia la corrutina de caminar
        StartCoroutine(WalkCoroutine());
        
    }

    void Update()
    {
        // Movimiento horizontal del jugador utilizando linearVelocity
        myrigidbody2D.linearVelocity = new Vector2(playerSpeed, myrigidbody2D.linearVelocity.y);

        // Salto del jugador
        if (Input.GetKeyDown(KeyCode.Space))
        {
            myrigidbody2D.linearVelocity = new Vector2(myrigidbody2D.linearVelocity.x, playerJumpForce);
            mySpriteRenderer.sprite = jumpSprite;
        }
        myrigidbody2D.linearVelocity = new Vector2(playerSpeed,myrigidbody2D.linearVelocity.y);
        


        if(Input.GetKeyDown(KeyCode.E))
        {
            Instantiate(Bullet, transform.position, Quaternion.identity);
        }
    }

    IEnumerator WalkCoroutine()
    {
        // Comprueba que haya sprites en el arreglo antes de cambiar el sprite
        while (walkSprites.Length > 0)
        {
            walkIndex = (walkIndex + 1) % walkSprites.Length;
            mySpriteRenderer.sprite = walkSprites[walkIndex];
            yield return new WaitForSeconds(0.1f);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("itemGood"))
        {
            Destroy(collision.gameObject);
            myGameManager.AddScore();
        }
        else if(collision.CompareTag("itemBad"))
        {
            Destroy(collision.gameObject);
            PlayerDeath();
        }
        else if(collision.CompareTag("DeathZone"))
        {
            PlayerDeath();
        }
        
       
    }


    void  PlayerDeath()
    {
        SceneManager.LoadScene("SampleScene");
    }

    
}
