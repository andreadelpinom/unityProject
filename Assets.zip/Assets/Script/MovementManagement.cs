using System.Collections;
using UnityEngine;

public class MovementManagement : MonoBehaviour
{
    private SpriteRenderer mySpriteRenderer;
    public Sprite[] mySprite;
    private int index = 0;

    void Start()
    {
        mySpriteRenderer = GetComponent<SpriteRenderer>();
        StartCoroutine(WalkCoRutine());
    }
    IEnumerator WalkCoRutine()
    {
        yield return new WaitForSeconds(0.05F);
        mySpriteRenderer.sprite = mySprite[index];
        index++;
        if(index ==6)
        {
            index = 0;
        }
        StartCoroutine(WalkCoRutine());
    }

    
}
